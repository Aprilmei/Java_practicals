package assignment_2;

// Interface RentallItem 

public interface RentallItem {

	// abstract method for all classes which implement the interface
	void RentItem(int RentalDays);

}
